num = int(input("정수를 입력:"))

if num>0:
    print("양수입니다.")
elif num == 0:
    print("0입니다.")
else:
    print("음수입니다.")